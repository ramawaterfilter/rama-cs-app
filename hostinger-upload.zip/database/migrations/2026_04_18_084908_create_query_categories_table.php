<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('query_categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('type')->nullable(); // product, query_type, subcategory, child_category
            $table->foreignId('parent_id')->nullable()->constrained('query_categories')->nullOnDelete();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('query_categories');
    }
};
